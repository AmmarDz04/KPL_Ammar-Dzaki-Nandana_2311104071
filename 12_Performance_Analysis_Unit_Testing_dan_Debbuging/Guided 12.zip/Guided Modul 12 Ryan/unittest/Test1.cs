﻿
using GuidedModul12Ryan;

namespace unittest
{
    [TestClass]
    public class Test1
    {
        [TestMethod]
        public void TestGrade()
        {
            string? result1 = Program.DetermineGrade(90);
            Assert.AreEqual("A", result1);

            string? result2 = Program.DetermineGrade(80);
            Assert.AreEqual("B", result2);

            string? result3 = Program.DetermineGrade(70);
            Assert.AreEqual("C", result3);

            string? result4 = Program.DetermineGrade(60);
            Assert.AreEqual("D", result4);

            string? result5 = Program.DetermineGrade(50);
            Assert.AreEqual("F", result5);
        }

        [TestMethod]
        public void TestInvalidGrades()
        {
            string? result6 = Program.DetermineGrade(-10);
            Assert.IsNull(result6);

            string? result7 = Program.DetermineGrade(110);
            Assert.IsNull(result7);
        }
    }

}

