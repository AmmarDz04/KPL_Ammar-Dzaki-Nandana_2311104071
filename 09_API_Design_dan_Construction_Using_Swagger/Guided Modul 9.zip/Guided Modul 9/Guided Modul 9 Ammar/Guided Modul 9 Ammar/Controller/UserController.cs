﻿using Guided_Modul_8_Ryan_Gabriel.Models;
using Microsoft.AspNetCore.Mvc;

namespace Guided_Modul_8_Ryan_Gabriel.Controller
{

    [ApiController]
    [Route("[controller]")]
    public class UserController : ControllerBase
    {
        private static List<User> users = new List<User>()
    {
        new User { id = 1, Name = "alisa", Email = "alisa@gmail.com" },
        new User { id = 2, Name = "bob", Email = "bob@gmail.com" },
    };

        [HttpGet]
        public ActionResult<List<User>> GetUser(int id)
        {
            return Ok(users);
        }
        [HttpGet("{id}")]
        public ActionResult<List<User>> GetUsers(int id)
        {
            var user = users.FirstOrDefault(u => u.id == id);
            if (user == null)
            {
                return NotFound();
            }
            return Ok(user);
        }

        [HttpPost]
        public ActionResult<User> CreateUser(UserDto userCreate)
        {
            int new_id = users.Count + 1;
            var user = new User()
            {
                id = new_id,
                Name = userCreate.Name,
                Email = userCreate.Email,
            };
            users.Add(user);
            return Ok(User);
        }
        [HttpPut("{id}")]
        public IActionResult UpdateUser(int id, UserDto userUpdate)
        {
            var user = users.FirstOrDefault(u => u.id == id);
            if (user == null)
            {
                return NotFound();
            }
            user.Name = userUpdate.Name;
            user.Email = userUpdate.Email;
            return Ok(user);
        }
        [HttpDelete("{id}")]
        public IActionResult DeleteUser(int id)
        {
            var user = users.FirstOrDefault(u => u.id == id);
            if (user == null)
            {
                return NotFound();
            }
            users.Remove(user);
            return Ok(user);
        }

    }

}
