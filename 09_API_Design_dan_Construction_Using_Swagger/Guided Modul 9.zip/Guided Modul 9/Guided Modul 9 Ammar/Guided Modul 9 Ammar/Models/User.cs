﻿namespace Guided_Modul_8_Ryan_Gabriel.Models
{
    public class User
    {   
        public int id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
