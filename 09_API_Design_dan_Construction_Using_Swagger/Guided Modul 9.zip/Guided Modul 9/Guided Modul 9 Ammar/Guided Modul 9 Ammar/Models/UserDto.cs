﻿namespace Guided_Modul_8_Ryan_Gabriel.Models
{
    public class UserDto
    {
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
