﻿namespace GuidedModul12Ryan
{
    public class Program
    {
        public static string? DetermineGrade(int score)
        {
            if (score < 0 || score > 100)
                return null;

            if (score >= 90) return "A";
            else if (score >= 80) return "B";
            else if (score >= 70) return "C";
            else if (score >= 60) return "D";
            else return "F";
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Aplikasi Penilaian Berjalan!");
        }
    }
}
